# Hesse–Allender–Barrington Corollary 6.3

The default target contains the review statements in `DiophantineNP.lean` and imports 80 local proof modules. The Lean toolchain and dependency manifest are copied from the full D_NP project. `HAB_REVIEW.md` gives the mathematical background and also refers to the larger development.

From this directory, with Git and elan installed, run

```sh
lake exe cache get
lake build
lake env lean DiophantineNP.lean
```

The last command checks the stated theorem and prints its axiom dependencies.
